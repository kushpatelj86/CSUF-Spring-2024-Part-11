# Commands
# To run this program you will need to do the following
# First, enter the Python virtual environment
# To do this, please run the command source bin/activate
# in the current directory.
# To run python3 DES.py

from Crypto.Cipher import DES

# Create an instance of the DES class
# and initialize the key
des = DES.new(b'13371337', DES.MODE_ECB)

# The plaintext
plainText = "BillyBob".encode()

print("Plain text: ", plainText)

# Encrypt the plaintext
cipherText = des.encrypt(plainText)

print ("Cipher text: ", cipherText)

# Decrypt the text
print ("Decrypted text: ", des.decrypt(cipherText))






