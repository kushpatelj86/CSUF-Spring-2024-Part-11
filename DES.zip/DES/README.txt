****
 C
****


Compiling:
---------
cd DES_c
make clean
make

Running:
-------
./des


*****
Java
*****

Compiling:
----------
cd DES_java
make clean
make

Running:
--------
java DES

*******
Python
*******

Compiling:
----------
None.

Running:
--------
cd DES_python
python DES.py
